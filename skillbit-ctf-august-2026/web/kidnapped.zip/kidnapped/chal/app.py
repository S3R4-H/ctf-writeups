from flask import Flask, render_template, redirect, url_for, request, flash, g,current_app
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from auth import jwt_required, generate_token
import os
import jwt


# Initialize app
app = Flask(__name__)
app.config.from_object('config.Config')

# Database setup
db = SQLAlchemy(app)


# Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    balance = db.Column(db.Float, nullable=False,default=10)
    role = db.Column(db.String(10), nullable=False, default='user')

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    price = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(10), nullable=False)

class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)

class PurchasedItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(10), nullable=False)



# Routes
@app.before_request
def load_cart_count():
    if request.cookies.get('auth_token'):
        try:
            decoded = jwt.decode(request.cookies.get('auth_token'), current_app.config['SECRET_KEY'], algorithms=['HS256'])
            user_id = decoded['user_id']
            request.cart_count = Cart.query.filter_by(user_id=user_id).count()
        except Exception:
            request.cart_count = 0
    else:
        request.cart_count = 0

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            token = generate_token(user.id, user.username, user.balance, user.role)

            response = redirect(url_for('products'))
            response.set_cookie('auth_token', token, httponly=True, samesite='Strict')
            return response

        flash('Invalid username or password!', 'danger')
        return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if not username or not password or not confirm_password:
            flash('All fields are required!', 'danger')
            return redirect(url_for('register'))

        if password != confirm_password:
            flash('Passwords do not match!', 'danger')
            return redirect(url_for('register'))

        if User.query.filter_by(username=username).first():
            flash('Username already exists!', 'danger')
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password)
        new_user = User(username=username, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/logout')
@jwt_required
def logout():
    response = redirect(url_for('index'))
    response.set_cookie('auth_token', '', expires=0)
    flash('Logged out successfully.', 'success')
    return response


@app.route('/products')
@jwt_required
def products():
    all_products = Product.query.all()
    return render_template('products.html', products=all_products)


@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
@jwt_required
def add_to_cart(product_id):
    user_id = request.user_id
    quantity = int(request.form.get('quantity', 1))
    product = Product.query.get_or_404(product_id)

    cart_item = Cart.query.filter_by(user_id=user_id, product_id=product_id).first()
    if cart_item:
        cart_item.quantity += quantity
    else:
        cart_item = Cart(user_id=user_id, product_id=product_id, quantity=quantity)
        db.session.add(cart_item)

    db.session.commit()
    flash(f'{product.name} has been added to your cart.', 'success')
    return redirect(url_for('products'))

@app.route('/update_cart_quantity/<int:cart_id>/<string:action>', methods=['POST'])
@jwt_required
def update_cart_quantity(cart_id, action):
    user_id = request.user_id
    cart_item = Cart.query.get_or_404(cart_id)

    # Ensure the cart item belongs to the current user
    if cart_item.user_id != user_id:
        flash('You are not authorized to update this item.', 'danger')
        return redirect(url_for('cart'))

    # Handle the action
    if action == 'increase':
        cart_item.quantity += 1
    elif action == 'decrease':
        if cart_item.quantity > 1:
            cart_item.quantity -= 1
        else:
            flash('Quantity cannot be less than 1. Use Remove to delete the item.', 'warning')
            return redirect(url_for('cart'))

    db.session.commit()
    flash('Cart updated successfully.', 'success')
    return redirect(url_for('cart'))


@app.route('/cart')
@jwt_required
def cart():
    user_id = request.user_id
    cart_items = db.session.query(Cart, Product).join(Product, Cart.product_id == Product.id).filter(Cart.user_id == user_id).all()
    return render_template('cart.html', cart_items=cart_items)

@app.route('/remove_from_cart/<int:cart_id>', methods=['POST'])
@jwt_required
def remove_from_cart(cart_id):
    user_id = request.user_id
    cart_item = Cart.query.get_or_404(cart_id)

    if cart_item.user_id != user_id:
        flash('You are not authorized to remove this item.', 'danger')
        return redirect(url_for('cart'))

    db.session.delete(cart_item)
    db.session.commit()
    flash('Item removed from your cart.', 'success')
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET', 'POST'])
@jwt_required
def checkout():
    CURRENCY_RATES = {"USD": 1, "EUR": 0.9, "JPY": 110}

    user_id = request.user_id
    username = request.username
    balance = request.balance
    role = request.role

    cart_items = db.session.query(Cart, Product).join(Product, Cart.product_id == Product.id).filter(Cart.user_id == user_id).all()

    if not cart_items:
        flash('Your cart is empty.', 'danger')
        return redirect(url_for('cart'))

    # Calculate total in USD
    total_in_usd = sum(cart.quantity * product.price for cart, product in cart_items)

    if request.method == 'POST':
        selected_currency = request.form.get('currency', 'USD')
        conversion_rate = CURRENCY_RATES.get(selected_currency, 1)

        # Convert total to selected currency
        total_in_selected_currency = total_in_usd * conversion_rate

        # Check if balance is sufficient
        if balance < total_in_selected_currency:
            flash(f'Insufficient balance! You need {total_in_selected_currency:.2f} {selected_currency}.', 'danger')
            return redirect(url_for('checkout'))

        # Deduct the balance
        new_balance = balance - total_in_selected_currency

        # Save purchased items to PurchasedItem table
        flag = None
        for cart, product in cart_items:
            purchased_item = PurchasedItem(
                user_id=user_id,
                product_id=product.id,
                quantity=cart.quantity,
                price=product.price,
                currency=selected_currency
            )
            db.session.add(purchased_item)

            # Check if FLAG product was purchased
            if product.name == 'FLAG':
                flag = os.getenv('FLAG', 'SkillBit{Fake_Flag_For_Testing}')

        # Clear the cart
        Cart.query.filter_by(user_id=user_id).delete()

        # Commit all changes to the database
        db.session.commit()

        # Reissue JWT token with the updated balance
        new_token = generate_token(user_id, username, new_balance, role)
        response = redirect(url_for('products'))
        response.set_cookie('auth_token', new_token, httponly=True, samesite='Strict')

        # Show the flag if purchased
        if flag:
            flash(f'Congratulations! Here is your flag: {flag}', 'success')
        else:
            flash(f'Checkout successful! Total: {total_in_selected_currency:.2f} {selected_currency}.', 'success')

        return response

    return render_template('checkout.html', cart_items=cart_items, total_in_usd=total_in_usd)


@app.route('/inventory')
@jwt_required
def inventory():
    user_id = request.user_id
    purchased_items = db.session.query(PurchasedItem, Product).join(Product, PurchasedItem.product_id == Product.id).filter(PurchasedItem.user_id == user_id).all()
    return render_template('inventory.html', purchased_items=purchased_items)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0')
