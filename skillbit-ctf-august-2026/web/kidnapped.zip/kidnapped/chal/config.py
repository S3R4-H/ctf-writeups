import os

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'default-secret-key')
    SQLALCHEMY_DATABASE_URI = 'sqlite:///store.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    PRIVATE_KEY_PATH = os.getenv('PRIVATE_KEY_PATH', './keys/private.key')
    PRIVATE_KEY_PATH = os.getenv('PUBLIC_KEY_PATH', './keys/public.key')