import os
from app import app, db, User, Product
from werkzeug.security import generate_password_hash

# Function to seed the database
def seed_data():
    # Initialize the database schema
    db.create_all()

    # Check if data already exists to avoid duplicate seeding
    if User.query.count() > 0 or Product.query.count() > 0:
        print("Database already seeded. Skipping...")
        return

    # Get admin password from environment variable
    admin_password = os.getenv('ADMIN_PASSWORD', 'adminpass')

    # Add admin user
    admin = User(username='admin', password=generate_password_hash(admin_password), balance=1337, role='admin')
    db.session.add(admin)

    # Add 20 fake products
    products = [
        Product(name='Gaming Laptop', price=1500, currency='USD'),
        Product(name='Smartphone', price=800, currency='USD'),
        Product(name='Wireless Earbuds', price=200, currency='USD'),
        Product(name='Mechanical Keyboard', price=120, currency='USD'),
        Product(name='4K Monitor', price=400, currency='USD'),
        Product(name='Gaming Chair', price=300, currency='USD'),
        Product(name='External SSD', price=100, currency='USD'),
        Product(name='Graphics Tablet', price=350, currency='USD'),
        Product(name='Bluetooth Speaker', price=150, currency='USD'),
        Product(name='Fitness Tracker', price=75, currency='USD'),
        Product(name='VR Headset', price=500, currency='USD'),
        Product(name='Drone', price=700, currency='USD'),
        Product(name='Smartwatch', price=250, currency='USD'),
        Product(name='Action Camera', price=300, currency='USD'),
        Product(name='Gaming Console', price=500, currency='USD'),
        Product(name='Noise-Canceling Headphones', price=250, currency='USD'),
        Product(name='Portable Power Bank', price=50, currency='USD'),
        Product(name='Electric Scooter', price=800, currency='USD'),
        Product(name='Smart Home Hub', price=180, currency='USD'),
        Product(name='Digital Photo Frame', price=100, currency='USD'),
        Product(name='FLAG', price=1337, currency='USD'),
    ]
    db.session.add_all(products)

    # Commit changes
    db.session.commit()
    print("Database seeded with admin user, regular user, and 20 fake products including the FLAG!")

# Run the seeding function
if __name__ == '__main__':
    with app.app_context():
        seed_data()
