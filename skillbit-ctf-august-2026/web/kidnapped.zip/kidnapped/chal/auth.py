import jwt
import datetime
from urllib.request import urlopen
from flask import redirect, url_for, current_app, request, make_response
from functools import wraps

def load_secret_key(PATH):
    return urlopen(PATH).read().strip()

KID = 'file:///app/keys/secret.txt'
SECRET_KEY = load_secret_key(KID)

def generate_token(user_id, username, balance, role):
    payload = {
        'user_id': user_id,
        'username': username,
        'balance': balance,
        'role': role,
        'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=1)
    }
    headers = {
        'kid': KID
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm='HS256', headers=headers)
    return token

def verify_token(token):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

def jwt_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = request.cookies.get('auth_token')
        if not token:
            return redirect(url_for('login'))

        try:
            headers = jwt.get_unverified_header(token)
            decoded = jwt.decode(token, load_secret_key(headers.get('kid')), algorithms=['HS256'])
            request.user_id = decoded.get('user_id')
            request.username = decoded.get('username')
            request.balance = decoded.get('balance')
            request.role = decoded.get('role')

            # If user is admin, change the balance to 31337
            if request.role == 'admin':
                request.balance = 31337
                new_token = generate_token(request.user_id, request.username, request.balance, request.role)
                response = make_response(f(*args, **kwargs))
                response.set_cookie('auth_token', new_token)
                return response

        except jwt.ExpiredSignatureError:
            return redirect(url_for('login'))
        except jwt.InvalidTokenError:
            return redirect(url_for('login'))

        if not request.user_id or request.balance is None or request.role is None:
            return redirect(url_for('login'))

        return f(*args, **kwargs)
    return decorated_function
